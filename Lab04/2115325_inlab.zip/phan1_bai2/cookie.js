var Name = document.getElementById("name");
var Val = document.getElementById("value"); 
var time = document.getElementById("expire");
var tablebody = document.getElementsByTagName("tbody")[0];
var but = document.getElementsByTagName("button")[0];

var curRow = 0; 
var curCol = 4; 
const data = [];

function Add() {
    if (but.classList.contains("edit")) {
        if (data[0] != Name.value) {
            // xoa cookie cu
            delCookie(data[0], data[1]);
        }
        // ghi de thuoc tinh cua cookie cu hoac them cookie moi trong truong hop xoa cookie cu
        addCookie(Name.value, Val.value, time.value);
        // cap nhat lai bang
        tablebody.querySelectorAll('tr').forEach(function (row) {
            if (row.firstChild.textContent == data[0]) {
                row.firstChild.innerHTML = Name.value;
                row.childNodes[1].innerHTML = Val.value;
                row.childNodes[2].innerHTML = time.value;
            }
        });
        but.innerHTML = "Add New Cookie";
        but.classList.remove("edit");
    }
    else {
        data[0] = Name.value;
        data[1] = Val.value;
        data[2] = time.value;
        addCookie(data[0], data[1], data[2]);
        addNewRow();
    }

    document.getElementsByTagName("button")[1].classList.remove("disabled");
}

function addCookie(tname, tvalue, tday) {
    let expTime = new Date(tday).toUTCString();
    let setCookies = tname + "=" + tvalue + "; expires=" + expTime;
    document.cookie = setCookies;
}


function addNewRow() {
    let row = tablebody.insertRow(curRow);
    for (let i = 0; i < curCol; i++){
        let cell = row.insertCell(i);
        if (i != curCol - 1) {
            cell.innerHTML = data[i];
        }
        else {
            cell.innerHTML = `<button type="button" onclick="Edit('${data[0]}','${data[1]}','${data[2]}')"
             class="btn btn-info w-50">Edit</button>`;
            cell.classList.add("text-center");
        }
    }
    curRow++;
}

function Delete() {
    let input = document.getElementById("deleteInput").value;
    let delName = tablebody.getElementsByTagName("tr")[0].firstChild.textContent;
    let delVal = tablebody.getElementsByTagName("tr")[0].childNodes[1].textContent;
    delCookie(delName, delVal, input);
    
    // delet row of cookie
    tablebody.deleteRow(input);
    curRow--;
}

function delCookie(tname, tday) {
    // delet cookie
    document.cookie = tname + "=" + tday + "; expires=Thu, 01 Jan 1970 00:00:00 UTC";
}


function Edit(tname, tvalue, tday) {
    data[0] = Name.value = tname;
    data[1] = Val.value = tvalue; 
    data[2] = time.value = tday;
    but.innerHTML = "Edit Cookie";
    but.classList.add("edit");
    document.getElementsByTagName("button")[1].classList.add("disabled");
}


